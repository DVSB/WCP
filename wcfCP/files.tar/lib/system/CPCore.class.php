<?php
/*
 * +-----------------------------------------+
 * | Copyright (c) 2009 Tobias Friebel		 |
 * +-----------------------------------------+
 * | Authors: Tobias Friebel <TobyF@Web.de>  |
 * +-----------------------------------------+
 *
 * Project: WCF Control Panel
 *
 * $Id$
 */

require_once (WCF_DIR . 'lib/page/util/menu/HeaderMenuContainer.class.php');
require_once (WCF_DIR . 'lib/page/util/menu/UserCPMenuContainer.class.php');
require_once (WCF_DIR . 'lib/system/style/Style.class.php');

class CPCore extends WCF implements HeaderMenuContainer, UserCPMenuContainer
{
	protected static $headerMenuObj= null;
	protected static $userCPMenuObj= null;

	/**
	 * Initialises the template engine.
	 */
	protected function initTPL()
	{
		// init style to get template pack id
		Style::changeStyle(0);

		global $packageDirs;
		require_once (WCF_DIR . 'lib/system/template/StructuredTemplate.class.php');
		self :: $tplObj= new StructuredTemplate(self :: getStyle()->templatePackID,
												self :: getLanguage()->getLanguageID(),
												ArrayUtil :: appendSuffix($packageDirs, 'templates/')
												);
		$this->assignDefaultTemplateVariables();
		self::getTPL()->assign('executeCronjobs',
								WCF::getCache()->get('cronjobs-'.PACKAGE_ID, 'nextExec') < TIME_NOW
								);
		self::getTPL()->assign('timezone', DateUtil::getTimezone());

		// check offline mode
		if (OFFLINE && !self :: getUser()->getPermission('admin.general.canUseAcp'))
		{
			$showOfflineError= true;
			foreach (self :: $availablePagesDuringOfflineMode as $type => $names)
			{
				if (isset ($_REQUEST[$type]))
				{
					foreach ($names as $name)
					{
						if ($_REQUEST[$type] == $name)
						{
							$showOfflineError= false;
							break 2;
						}
					}
					break;
				}
			}

			if ($showOfflineError)
			{
				self :: getTPL()->display('offline');
				exit;
			}
		}

		// user ban
		if (self :: getUser()->banned && (!isset ($_REQUEST['page']) || $_REQUEST['page'] != 'LegalNotice'))
		{
			require_once (WCF_DIR . 'lib/system/exception/PermissionDeniedException.class.php');
			throw new PermissionDeniedException();
		}
	}

	/**
	 * @see WCF::loadDefaultCacheResources()
	 */
	protected function loadDefaultCacheResources()
	{
		parent :: loadDefaultCacheResources();
	}

	/**
	 * Returns the active style object.
	 *
	 * @return	Style
	 */
	public static final function getStyle()
	{
		return Style::getStyle();
	}

	/**
	 * Initialises the page header menu.
	 */
	protected static function initHeaderMenu()
	{
		require_once (WCF_DIR . 'lib/page/util/menu/HeaderMenu.class.php');
		self :: $headerMenuObj= new HeaderMenu();

		if (HeaderMenu :: getActiveMenuItem() == '')
			HeaderMenu :: setActiveMenuItem('cp.header.menu.start');
	}

	/**
	 * Initialises the page header menu.
	 */
	protected static function initUserCPMenu()
	{
		require_once (WCF_DIR . 'lib/page/util/menu/UserCPMenu.class.php');
		self :: $userCPMenuObj= UserCPMenu :: getInstance();
	}

	/**
	 * @see WCF::getOptionsFilename()
	 */
	protected function getOptionsFilename()
	{
		return CP_DIR . 'options.inc.php';
	}

	/**
	 * @see HeaderMenuContainer::getHeaderMenu()
	 */
	public static final function getHeaderMenu()
	{
		if (self :: $headerMenuObj === null)
		{
			self :: initHeaderMenu();
		}

		return self :: $headerMenuObj;
	}

	/**
	 * @see UserCPMenuContainer::getUserCPMenu()
	 */
	public static final function getUserCPMenu()
	{
		if (self :: $userCPMenuObj === null)
		{
			self :: initUserCPMenu();
		}

		return self :: $userCPMenuObj;
	}
}
?>