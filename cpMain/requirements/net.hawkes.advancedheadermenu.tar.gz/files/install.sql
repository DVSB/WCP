ALTER TABLE `wcf1_header_menu_item` ADD `parentMenuItem` VARCHAR( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL;
ALTER TABLE `wcf1_header_menu_item` ADD `isNative` TINYINT( 1 ) UNSIGNED NOT NULL DEFAULT '1'; 
ALTER TABLE `wcf1_header_menu_item` ADD `isActive` TINYINT( 1 ) UNSIGNED NOT NULL DEFAULT '1';
