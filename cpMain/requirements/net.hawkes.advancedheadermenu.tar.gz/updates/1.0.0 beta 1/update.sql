ALTER TABLE `wcf1_header_menu_item` ADD `isActive` TINYINT( 1 ) UNSIGNED NOT NULL DEFAULT '1';
