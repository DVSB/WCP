@ALTER TABLE wcf1_help_item ADD permissions TEXT NULL;
@ALTER TABLE wcf1_help_item ADD options TEXT NULL;
@ALTER TABLE wcf1_help_item ADD isDisabled TINYINT(1) NOT NULL DEFAULT 0;