DROP TABLE IF EXISTS wcf1_captcha;
CREATE TABLE wcf1_captcha (
	captchaID int(10) unsigned NOT NULL auto_increment,
	captchaString varchar(255) NOT NULL default '',
	captchaDate int(10) unsigned NOT NULL default 0,
	PRIMARY KEY (captchaID)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;