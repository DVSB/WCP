DROP TABLE IF EXISTS wcf1_style_to_package;
CREATE TABLE wcf1_style_to_package (
	styleID INT(10) NOT NULL,
	packageID INT(10) NOT NULL,
	isDefault TINYINT(1) NOT NULL DEFAULT 0,
	disabled TINYINT(1) NOT NULL DEFAULT 0,
	UNIQUE KEY (styleID, packageID)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

ALTER TABLE wcf1_user ADD KEY (styleID);