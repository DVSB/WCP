DROP TABLE IF EXISTS wcf1_template_pack;
CREATE TABLE wcf1_template_pack (
	templatePackID int(10) unsigned NOT NULL auto_increment,
	templatePackName varchar(255) NOT NULL default '',
	templatePackFolderName varchar(255) NOT NULL default '',
	PRIMARY KEY (templatePackID)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

ALTER TABLE wcf1_template ADD templatePackID INT(10) UNSIGNED NOT NULL DEFAULT 0;
ALTER TABLE wcf1_template ADD INDEX (packageID, templatePackID, templateName);